#include <stdio.h>

int main() {
    int n;
    int i;

    do {
        printf("Digite um número \n(digite 0 para encerrar o programa): ");
        scanf("%d", &n);

        printf("Tabuada do número:\n");

        for (i = 1; i <= 10; i++) {
            printf("%d X %d = %d\n", i, n, i * n);
        }

    } while (n != 0);

    return 0;
}

